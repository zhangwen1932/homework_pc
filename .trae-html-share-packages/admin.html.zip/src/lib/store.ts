import { useSyncExternalStore } from 'react'
import type { HomeworkItem } from '../types'
import { todayKey } from './date'

const STORAGE_KEY = 'homework-agent/items/v1'

type HomeworkDB = Record<string, HomeworkItem[]>

const EMPTY: HomeworkItem[] = []
const listeners = new Set<() => void>()

function safeRead(): HomeworkDB | undefined {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (!raw) return undefined
    const parsed: unknown = JSON.parse(raw)
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) return undefined
    return parsed as HomeworkDB
  } catch {
    return undefined
  }
}

function safeWrite(next: HomeworkDB) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(next))
  } catch {
    // 隐私模式等场景下写入失败，仅影响持久化，不影响当前会话
  }
}

let nextId = 0
export function uid(prefix = 'id'): string {
  nextId += 1
  return `${prefix}_${Date.now().toString(36)}_${nextId}`
}

/** 首次打开时塞一份示例数据，方便直接体验 */
function buildSeed(): HomeworkDB {
  const date = todayKey()
  const now = Date.now()
  const drafts: Array<[string, string, HomeworkItem['status'], number?, number?]> = [
    ['数学', '口算题卡 第 12 页', 'doing', 20],
    ['语文', '生字抄写 3 遍', 'todo', 15],
    ['语文', '背诵《静夜思》', 'done', 10, 8],
    ['英语', 'Unit 4 单词听写', 'todo', 10],
  ]
  const items = drafts.map(([subject, title, status, estimated, actual], index) => ({
    id: `seed_${index}`,
    date,
    subject,
    title,
    status,
    estimatedMinutes: estimated,
    actualMinutes: actual,
    createdAt: now - index * 1000,
    updatedAt: now - index * 1000,
  }))
  return { [date]: items }
}

function loadInitial(): HomeworkDB {
  const stored = safeRead()
  if (stored) return stored
  const seeded = buildSeed()
  safeWrite(seeded)
  return seeded
}

let db: HomeworkDB = loadInitial()

function commit(next: HomeworkDB) {
  db = next
  safeWrite(next)
  listeners.forEach((listener) => listener())
}

function subscribe(listener: () => void): () => void {
  listeners.add(listener)
  return () => {
    listeners.delete(listener)
  }
}

export const homeworkStore = {
  subscribe,

  getAll(): HomeworkDB {
    return db
  },

  getByDate(date: string): HomeworkItem[] {
    return db[date] ?? EMPTY
  },

  findById(id: string): HomeworkItem | undefined {
    for (const items of Object.values(db)) {
      const hit = items.find((item) => item.id === id)
      if (hit) return hit
    }
    return undefined
  },

  insert(item: HomeworkItem) {
    const items = db[item.date] ?? []
    commit({ ...db, [item.date]: [...items, item] })
  },

  patch(id: string, changes: Partial<HomeworkItem>) {
    const next: HomeworkDB = {}
    let touched = false
    for (const [date, items] of Object.entries(db)) {
      next[date] = items.map((item) => {
        if (item.id !== id) return item
        touched = true
        return { ...item, ...changes, id: item.id, updatedAt: Date.now() }
      })
    }
    if (touched) commit(next)
  },

  remove(id: string) {
    const next: HomeworkDB = {}
    let touched = false
    for (const [date, items] of Object.entries(db)) {
      const kept = items.filter((item) => item.id !== id)
      if (kept.length !== items.length) touched = true
      next[date] = kept
    }
    if (touched) commit(next)
  },

  resetToSeed() {
    commit(buildSeed())
  },

  clearAll() {
    commit({})
  },
}

/** 订阅某一天的作业列表 */
export function useHomework(date: string): HomeworkItem[] {
  return useSyncExternalStore(subscribe, () => homeworkStore.getByDate(date))
}
