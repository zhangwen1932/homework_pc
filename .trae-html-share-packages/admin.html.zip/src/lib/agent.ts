import type { AgentRunResult, ToolTraceItem } from '../types'
import { formatDateLabel } from './date'
import { chatWithTools, getLlmStatus, type LlmMessage } from './llm'
import { runMockAgent } from './mockAgent'
import { executeTool, toolSchemas, type ToolContext } from './tools'

const MAX_ROUNDS = 6

function systemPrompt(ctx: ToolContext): string {
  return [
    '你是「作业小管家」，一个帮家长记录孩子作业的 AI Agent。',
    '',
    `当前日期：${ctx.date}（${formatDateLabel(ctx.date)}）`,
    '',
    '工作规则：',
    '1. 用户用自然语言描述作业情况时，先决定要调用哪些工具，然后调用工具，不要凭空编造作业内容。',
    '2. 不确定存在哪些作业时，先用 list_homework 查询当天清单，再决定是更新还是新增。',
    '3. 日期默认使用"当前日期"，只有用户明确说"明天/昨天/后天"等才换算成对应日期。',
    '4. 一句话里包含多件事时，可以一次调用多个工具，例如同时把数学标记完成、新增语文作文。',
    '5. 工具执行完后，用简洁自然的中文汇报做了什么，并说明当天还剩几项作业；不要复述 JSON，也不要输出工具名。',
    '6. 与记录作业无关的问题，礼貌地把话题拉回来，并给一句示例说法。',
  ].join('\n')
}

async function runLlmAgent(input: string, ctx: ToolContext): Promise<AgentRunResult> {
  const messages: LlmMessage[] = [
    { role: 'system', content: systemPrompt(ctx) },
    { role: 'user', content: input },
  ]
  const trace: ToolTraceItem[] = []
  let lastContent = ''

  for (let round = 0; round < MAX_ROUNDS; round += 1) {
    const reply = await chatWithTools(messages, toolSchemas)
    lastContent = reply.content || lastContent

    if (!reply.toolCalls.length) {
      return { reply: reply.content.trim() || lastContent || '处理完成。', trace, mode: 'llm' }
    }

    messages.push({ role: 'assistant', content: reply.content || null, tool_calls: reply.toolCalls })

    for (const call of reply.toolCalls) {
      let args: unknown = {}
      try {
        args = JSON.parse(call.function.arguments || '{}')
      } catch {
        args = {}
      }
      const item = executeTool(call.function.name, args, ctx)
      trace.push(item)
      messages.push({
        role: 'tool',
        tool_call_id: call.id,
        content: JSON.stringify({ ok: item.ok, summary: item.summary, data: item.data }),
      })
    }
  }

  return { reply: lastContent || '已经帮你更新完了。', trace, mode: 'llm' }
}

/** 有 API Key 走真实模型 tool calling，否则降级到本地规则模拟，保证 demo 随时可跑 */
export async function runAgent(input: string, ctx: ToolContext): Promise<AgentRunResult> {
  const status = await getLlmStatus()

  if (!status.configured) {
    // 本地规则是同步执行的，稍等一下让界面上的"正在调用工具"过程可见
    await new Promise((resolve) => setTimeout(resolve, 350))
    const result = runMockAgent(input, ctx)
    return { ...result, mode: 'mock' }
  }

  try {
    return await runLlmAgent(input, ctx)
  } catch (error) {
    const reason = error instanceof Error ? error.message : String(error)
    const result = runMockAgent(input, ctx)
    return {
      reply: `真实模型调用失败（${reason}），已自动降级为本地模拟：\n\n${result.reply}`,
      trace: result.trace,
      mode: 'mock',
    }
  }
}
