import type { ToolTraceItem } from '../types'
import { parseRelativeDate } from './date'
import { homeworkStore } from './store'
import { buildDailySummary, executeTool, type ToolContext } from './tools'

/** 未配置模型时使用的本地规则引擎，模拟一次 tool calling 过程 */
const SUBJECTS = ['道德与法治', '信息技术', '语文', '数学', '英语', '物理', '化学', '生物', '历史', '地理', '政治', '科学', '美术', '音乐', '体育', '编程']

const DONE_RE = /(写完|做完|完成|搞定|打卡|结束)/
const TODO_RE = /(没写完|没做完|还没写|还没做|还没|没写|没做|没完成|未完成|没开始|没弄)/
const DOING_RE = /(正在|在做|写着|开始写|做了一半|写了一半|进行中)/
const DELETE_RE = /(删|取消|不用做|不做了|去掉|移除|记错)/
const QUERY_RE = /(有什么|有哪些|哪些|查看|看看|列一下|列出|清单|还剩什么)/
const SUMMARY_RE = /(统计|汇总|总结|完成情况|汇报|进度|怎么样|如何|多少)/
const REMAIN_RE = /(还有|还剩|剩下|剩余|欠)/
const CONTENT_RE = /(作业|卷子|试卷|练习|作文|背诵|抄写|默写|听写|朗读|预习|复习|手抄报|实验|口算|单词|题|页|本|张)/

interface PlannedCall {
  name: string
  args: Record<string, unknown>
}

export interface MockRunResult {
  reply: string
  trace: ToolTraceItem[]
}

interface Segment {
  subject: string
  text: string
}

/** 按学科名把一句话拆成多段，支持"数学写完了语文还没写"这类连说 */
function splitBySubject(text: string): { prefix: string; items: Segment[] } {
  const hits: Array<{ index: number; subject: string }> = []
  for (const subject of SUBJECTS) {
    let from = 0
    for (;;) {
      const index = text.indexOf(subject, from)
      if (index === -1) break
      hits.push({ index, subject })
      from = index + subject.length
    }
  }

  // 长学科名优先，避免短名重叠切分
  hits.sort((a, b) => b.subject.length - a.subject.length || a.index - b.index)
  const accepted: Array<{ index: number; subject: string }> = []
  for (const hit of hits) {
    const end = hit.index + hit.subject.length
    const overlapped = accepted.some((other) => hit.index < other.index + other.subject.length && other.index < end)
    if (!overlapped) accepted.push(hit)
  }
  accepted.sort((a, b) => a.index - b.index)

  const items = accepted.map((hit, i) => {
    const next = accepted[i + 1]
    return { subject: hit.subject, text: text.slice(hit.index, next ? next.index : text.length) }
  })
  return { prefix: accepted.length ? text.slice(0, accepted[0].index) : text, items }
}

function parseMinutes(text: string): number | undefined {
  let total = 0
  let hit = false
  const hour = /(\d+(?:\.\d+)?)\s*个?\s*小时/.exec(text)
  if (hour) {
    total += Number(hour[1]) * 60
    hit = true
  } else if (/半\s*个?\s*小时/.test(text)) {
    total += 30
    hit = true
  }
  const minute = /(\d+)\s*分钟/.exec(text)
  if (minute) {
    total += Number(minute[1])
    hit = true
  }
  return hit && total > 0 ? Math.round(total) : undefined
}

/** 把一段话里剩下的内容当作作业名 */
function extractTitle(text: string, subject: string): string {
  let result = text.split(subject).join('')
  result = result.replace(/(写完|做完|完成|搞定|打卡|结束)/g, '')
  result = result.replace(/(还有|还剩|剩下|剩余|欠|没写完|没做完|还没写|还没做|还没|没写|没做|没完成|未完成|没开始|没弄)/g, '')
  result = result.replace(/(正在|在做|开始写|写着|做了一半|写了一半|进行中|开始)/g, '')
  result = result.replace(/(删掉|删除|删|取消|不用做了|不用做|不做了|去掉|移除)/g, '')
  result = result.replace(/(今天|明天|后天|大后天|昨天|前天|早上|上午|中午|下午|晚上|今晚|当天)/g, '')
  result = result.replace(/(已经|都|全部|把|给|一下|这|那|的|了|是|要|有|在|预计|大概|大约|差不多|用了|耗时|一共|总共)/g, '')
  result = result.replace(/(\d+(?:\.\d+)?\s*个?\s*(?:小时|分钟|分)|半\s*个?\s*小时)/g, '')
  result = result.replace(/[，,。.！!？?、;；:："'“”‘’()（）\s]/g, '')
  result = result.replace(/^(一|两|三|四|五|几)(篇|张|页|道|个|本|套|份)/, '')
  return result
}

function planCalls(text: string, date: string): { calls: PlannedCall[]; unclear: string[] } {
  const calls: PlannedCall[] = []
  const unclear: string[] = []
  const { prefix, items } = splitBySubject(text)

  const globalText = items.length ? prefix : text
  if (SUMMARY_RE.test(globalText)) calls.push({ name: 'get_daily_summary', args: { date } })
  if (QUERY_RE.test(globalText)) calls.push({ name: 'list_homework', args: { date } })

  for (const segment of items) {
    const existing = homeworkStore.getByDate(date).filter((item) => item.subject === segment.subject)
    const title = extractTitle(segment.text, segment.subject)
    const minutes = parseMinutes(segment.text)

    if (DELETE_RE.test(segment.text)) {
      calls.push({ name: 'delete_homework', args: { date, subject: segment.subject, title: title || undefined } })
      continue
    }
    if (SUMMARY_RE.test(segment.text) || QUERY_RE.test(segment.text)) {
      if (!calls.some((call) => call.name === 'get_daily_summary')) calls.push({ name: 'get_daily_summary', args: { date } })
      continue
    }
    if (TODO_RE.test(segment.text) && existing.length) {
      calls.push({ name: 'update_homework', args: { date, subject: segment.subject, status: 'todo' } })
      continue
    }
    if (DOING_RE.test(segment.text) && existing.length) {
      calls.push({ name: 'update_homework', args: { date, subject: segment.subject, status: 'doing' } })
      continue
    }
    if (DONE_RE.test(segment.text) && existing.length) {
      calls.push({
        name: 'update_homework',
        args: { date, subject: segment.subject, status: 'done', ...(minutes ? { actual_minutes: minutes } : {}) },
      })
      continue
    }

    // 新增：老师刚布置的、或者之前没记录过的
    if (CONTENT_RE.test(segment.text) || REMAIN_RE.test(segment.text) || title) {
      calls.push({
        name: 'add_homework',
        args: {
          date,
          subject: segment.subject,
          title: title || `${segment.subject}作业`,
          ...(minutes ? { estimated_minutes: minutes } : {}),
        },
      })
      if (DONE_RE.test(segment.text)) {
        calls.push({ name: 'update_homework', args: { date, subject: segment.subject, status: 'done' } })
      }
      continue
    }

    unclear.push(segment.text || segment.subject)
  }

  return { calls, unclear }
}

function composeReply(date: string, trace: ToolTraceItem[], unclear: string[]): string {
  const lines: string[] = []

  if (trace.length) {
    const mutated = trace.some((item) => item.ok && item.name !== 'get_daily_summary' && item.name !== 'list_homework')
    lines.push(mutated ? '好的，已经帮你更新到作业本上了：' : '这是当前的作业情况：')
    lines.push(...trace.map((item) => `${item.ok ? '·' : '⚠️'} ${item.summary}`))
  }

  if (unclear.length) {
    lines.push(`没太看懂「${unclear.join('」「')}」，可以试试"数学写完了"或者"明天有英语单词听写"`)
  }

  if (!trace.length && !unclear.length) {
    lines.push('没听出要记录什么作业，可以这样说：')
    lines.push('· 数学口算题卡写完了，用了 25 分钟')
    lines.push('· 明天有英语单词听写')
    lines.push('· 今天作业完成得怎么样？')
  }

  const askedSummary = trace.some((item) => item.name === 'get_daily_summary')
  const summary = buildDailySummary(date)
  if (summary.total && !askedSummary) {
    lines.push('')
    lines.push(
      `📊 共 ${summary.total} 项，已完成 ${summary.done} 项${
        summary.pending.length
          ? `，还剩：${summary.pending.map((item) => `${item.subject}·${item.title}`).join('、')}`
          : '，全部完成，太棒了 🎉'
      }`,
    )
  }

  return lines.join('\n')
}

export function runMockAgent(input: string, ctx: ToolContext): MockRunResult {
  const text = input.trim()
  if (!text) return { reply: '想记录点什么呢？', trace: [] }

  const date = parseRelativeDate(text, ctx.date) ?? ctx.date
  const { calls, unclear } = planCalls(text, date)
  const trace = calls.map((call) => executeTool(call.name, call.args, ctx))

  return { reply: composeReply(date, trace, unclear), trace }
}
