import type { IncomingMessage, ServerResponse } from 'node:http'
import { fileURLToPath } from 'node:url'
import react from '@vitejs/plugin-react'
import { defineConfig, loadEnv, type Plugin } from 'vite'

const entry = (path: string) => fileURLToPath(new URL(path, import.meta.url))

const DEFAULT_BASE_URL = 'https://api.openai.com/v1'
const DEFAULT_MODEL = 'gpt-4o-mini'

function sendJson(res: ServerResponse, statusCode: number, payload: unknown) {
  res.statusCode = statusCode
  res.setHeader('Content-Type', 'application/json; charset=utf-8')
  res.end(JSON.stringify(payload))
}

function readBody(req: IncomingMessage): Promise<string> {
  return new Promise((resolve, reject) => {
    const chunks: Buffer[] = []
    req.on('data', (chunk: Buffer) => chunks.push(chunk))
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')))
    req.on('error', reject)
  })
}

/**
 * 把模型请求放在开发服务器上转发，API Key 只存在于 Node 进程，
 * 不会被打进浏览器产物。
 */
function llmProxyPlugin(): Plugin {
  let apiKey = ''
  let baseUrl = DEFAULT_BASE_URL
  let model = DEFAULT_MODEL

  return {
    name: 'homework-agent:llm-proxy',

    config(_config, env) {
      const loaded = loadEnv(env.mode, process.cwd(), '')
      apiKey = (loaded.OPENAI_API_KEY || process.env.OPENAI_API_KEY || '').trim()
      baseUrl = (loaded.OPENAI_BASE_URL || process.env.OPENAI_BASE_URL || DEFAULT_BASE_URL).replace(/\/+$/, '')
      model = loaded.OPENAI_MODEL || process.env.OPENAI_MODEL || DEFAULT_MODEL
    },

    configureServer(server) {
      server.middlewares.use('/api/llm', async (req, res) => {
        const path = (req.url || '/').split('?')[0]

        if (req.method === 'GET' && (path === '/status' || path === '/')) {
          sendJson(res, 200, { ok: true, configured: Boolean(apiKey), model, baseUrl })
          return
        }

        if (req.method === 'POST' && path === '/chat') {
          const body = await readBody(req)

          if (!apiKey) {
            sendJson(res, 200, {
              ok: false,
              reason: 'no_key',
              message: '未检测到 OPENAI_API_KEY，请在项目根目录 .env 中配置后重启 dev server',
            })
            return
          }

          try {
            const started = Date.now()
            const upstream = await fetch(`${baseUrl}/chat/completions`, {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                Authorization: `Bearer ${apiKey}`,
              },
              body,
            })
            const text = await upstream.text()
            server.config.logger.info(
              `[llm] model=${model} status=${upstream.status} ${Date.now() - started}ms`,
            )
            res.statusCode = upstream.status
            res.setHeader('Content-Type', 'application/json; charset=utf-8')
            res.end(text)
          } catch (error) {
            sendJson(res, 502, {
              ok: false,
              reason: 'upstream_error',
              message: `调用模型失败：${error instanceof Error ? error.message : String(error)}`,
            })
          }
          return
        }

        sendJson(res, 404, { ok: false, reason: 'not_found' })
      })

      const hint = apiKey ? `已配置模型 ${model}` : '未配置 OPENAI_API_KEY，将使用本地模拟模式'
      server.config.logger.info(`[homework-agent] ${hint}`)
    },
  }
}

// https://vite.dev/config/
export default defineConfig({
  plugins: [react(), llmProxyPlugin()],
  build: {
    rollupOptions: {
      input: {
        main: entry('./index.html'),
        admin: entry('./admin.html'),
      },
    },
  },
})
